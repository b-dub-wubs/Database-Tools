USE [DNB]
GO

/****** Object:  StoredProcedure [dbo].[sp_create_duns_segmentation_n1]    Script Date: 11/26/2018 5:52:03 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[sp_create_duns_segmentation_n1]
AS 

	IF OBJECT_ID('tempdb..#tmp') IS NOT NULL
		DROP TABLE #tmp

	-- ID Business Type
	SELECT 
		[a].[Duns Number],
		CASE WHEN [l].[DUNS_Number__c] IS NULL THEN 'nl' ELSE 'pl' END AS [nl_pl],
		CASE WHEN [a].[Year Started] >= 2011 THEN '2011+'
			 WHEN [a].[Year Started] >= 2007 THEN '2007 - 2010'
			 WHEN [a].[Year Started] >= 2003 THEN '2003 - 2006'
			 WHEN [a].[Year Started] >= 1997 THEN '1997 - 2002'
			 WHEN [a].[Year Started] < 1997 THEN '<=1996'
			 ELSE 'Other'
		END AS [year_segment],
		[sr].[region],
		CASE WHEN [a].[Paydex Range Code] IN ( '1','2','3' ) THEN '1' ELSE '0' END AS has_paydex_flag,
		[sdx].[sic_division],
		[esx].[emp_segment_name]
	INTO
		#tmp
	FROM
		[DNB].[dbo].[OverallDnbBusinesses_current] AS [a]
		JOIN [Analytics_WS].[OM].[sic_division_xmap] AS [sdx]
			ON [sdx].[two_digit_sic] = LEFT([a].[Primary SIC 8 Digit], 2)
		JOIN [Analytics_WS].[OM].[state_to_region_xmap] AS [sr]
			ON [sr].[state_full_name] = [a].[State - Province]
		LEFT JOIN [Analytics_WS].[OM].[emp_segment_xmap] AS [esx]
			ON [a].[Emp Total] BETWEEN [esx].[min_emp_size] AND [esx].[max_emp_size]
		LEFT JOIN (
			SELECT DISTINCT [DUNS_Number__c] FROM [Salesforce_Repl].[dbo].[Lead]
		) AS [l]
			ON [l].[DUNS_Number__c] = [a].[Duns Number]

	IF OBJECT_ID('tempdb..[#tmp3]') IS NOT NULL
		DROP TABLE [#tmp3]
		
	SELECT
		[t].[Duns Number]
		,[t].[Response_Rate] AS [actual_rr]
		,[t].[LTF_perc] AS [actual_ltf]
		,[lsnt].[Median_RR_perc] AS [threshold_rr]
		,[lsnt].[RR_1_perc] AS threshold_rr3
		,[lsnt].[RR_2_perc] AS threshold_rr2
		,[lsnt].[LTF_perc] AS [threshold_ltf]
		,t.segments
		,[lsnt].[SIC_Division]
	INTO
		[#tmp3]
	FROM
		(
			SELECT
				[t].*
				,[lsnt].[Number_of_Records]
				,[lsnt].[Response_Rate]
				,[lsnt].[LTF_perc]
				,[lsnt].[DNB_Mailable_Population]
				,[lsnt].[DNB_Current_Month_Count]
				,[lsnt].[Segments]
			FROM
				[#tmp] AS [t]
				LEFT JOIN [Analytics_WS].[OM].[list_segmentation_n1] AS [lsnt]
					ON [lsnt].[has_paydex_flag] = [t].[has_paydex_flag]
					   AND [lsnt].[NL_PL] = [t].[nl_pl]
					   AND [lsnt].[region] = [t].[region]
					   AND [lsnt].[year_segment] = [t].[year_segment]
					   AND [lsnt].[SIC_Division] = [t].[sic_division]
					   AND [lsnt].[Empl_Segment] = [t].[emp_segment_name]
		) AS [t]
		LEFT JOIN [Analytics_WS].[OM].[list_segmentation_n1_thresholds] AS [lsnt]
			ON [lsnt].[SIC_Division] = [t].[SIC_Division]
			AND [lsnt].[NL_PL] = [t].[NL_PL]

	IF OBJECT_ID('[DNB].[dbo].duns_segmentation_n1') IS NOT NULL
		DROP TABLE [DNB].[dbo].duns_segmentation_n1

	SELECT
		[t].[Duns Number]
		,CASE WHEN [t].[actual_rr] > [t].[threshold_rr] AND [t].[actual_ltf] > [t].[threshold_ltf] THEN 'Growth'
			  WHEN [t].[actual_rr] > [t].[threshold_rr] THEN 'Unknown Growth'
			  WHEN [t].[actual_ltf] > [t].[threshold_ltf] THEN 'Vintage'
			  ELSE 'Mainstream'
		END AS segment_n1
		,CASE WHEN [t].[actual_rr] > [t].threshold_rr3 AND [t].[actual_ltf] > [t].[threshold_ltf] THEN 'Growth'
			  WHEN [t].[actual_rr] > [t].threshold_rr3 THEN 'Unknown Growth'
			  WHEN [t].[actual_ltf] > [t].[threshold_ltf] THEN 'Vintage'
			  ELSE 'Mainstream'
		END AS segment_n2
		,CASE WHEN [t].[actual_rr] > [t].threshold_rr2 AND [t].[actual_ltf] > [t].[threshold_ltf] THEN 'Growth'
			  WHEN [t].[actual_rr] > [t].threshold_rr2 THEN 'Unknown Growth'
			  WHEN [t].[actual_ltf] > [t].[threshold_ltf] THEN 'Vintage'
			  ELSE 'Mainstream'
		END AS segment_n3
		,segments AS n1_segment_string
		,[t].[SIC_Division]
	INTO
		[DNB].[dbo].duns_segmentation_n1
	FROM
		[#tmp3] AS [t]

	CREATE UNIQUE CLUSTERED INDEX cInd ON [DNB].[dbo].duns_segmentation_n1 ([Duns Number])
GO





[Analytics_WS].[OM].[sic_division_xmap]



USE [Analytics_WS]
GO

/****** Object:  Table [OM].[sic_division_xmap]    Script Date: 11/29/2018 5:30:58 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [OM].[sic_division_xmap](
	[sic_division] [varchar](255) NULL,
	[two_digit_sic] [char](2) NULL
) ON [PRIMARY]
GO






[Analytics_WS].[OM].[state_to_region_xmap]

USE [Analytics_WS]
GO

/****** Object:  Table [OM].[state_to_region_xmap]    Script Date: 11/29/2018 5:32:55 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [OM].[state_to_region_xmap](
	[state_full_name] [varchar](255) NULL,
	[state_abbrev] [varchar](255) NULL,
	[region] [varchar](255) NULL
) ON [PRIMARY]
GO



[Analytics_WS].[OM].[emp_segment_xmap]
[Analytics_WS].[OM].[list_segmentation_n1_thresholds]


