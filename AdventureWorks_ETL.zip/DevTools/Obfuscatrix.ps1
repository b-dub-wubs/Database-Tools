﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2019 v5.6.157
	 Created on:   	2/7/2019 9:25 PM
	 Created by:   	bwarner
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>



$svi=@('s26','s28')
$wsv=@('s50','sdw-bitools-p01','1588P72','s67','s68','sdw-dascript-p01')


$TP = 'C:\Users\bwarner\source\repos\Database-Tools\AdventureWorksTools'

gci -LiteralPath $TP -Recurse | %{
switch($_.PSISContainer)
  {
    $true  {  }
    $false {  } 
  }
}